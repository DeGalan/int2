$(document).ready(function() {
    $("#msg-1").click(function() {
        $("#msg-2").toggle("hide");
    });
    $("#msg-2").click(function() {
        $("#msg-3").toggle("hide");
    });
    $("#msg-3").click(function() {
        $("#msg-4").toggle("hide");
    });
    $("#msg-4").click(function() {
        $("#msg-5").toggle("hide");
    });
    $("#msg-5").click(function() {
        $("#msg-6").toggle("hide");
    });
    $("#msg-6").click(function() {
        $("#msg-7").toggle("hide");
    });
    $("#msg-7").click(function() {
        $("#msg-8").toggle("hide");
    });
    $("#msg-8").click(function() {
        $("#msg-9").toggle("hide");
    });
    $("#msg-9").click(function() {
        $("#msg-10").toggle("hide");
    });
    $("#msg-10").click(function() {
        $("#msg-11").toggle("hide");
    });
    $("#msg-11").click(function() {
        $("#msg-12").toggle("hide");
    });
    $("#msg-12").click(function() {
        $("#msg-13").toggle("hide");
    });
    $("#msg-13").click(function() {
        $("#msg-14").toggle("hide");
    });
    $("#msg-14").click(function() {
        $("#msg-15").toggle("hide");
    });
    $("#msg-15").click(function() {
        $("#msg-16").toggle("hide");
    });
    $("#msg-16").click(function() {
        $("#msg-17").toggle("hide");
    });
    $("#msg-17").click(function() {
        $("#msg-18").toggle("hide");
    });
    $("#msg-18").click(function() {
        $("#msg-19").toggle("hide");
    });
    $("#msg-19").click(function() {
        $("#msg-20").toggle("hide");
    });
    $("#msg-20").click(function() {
        $("#msg-21").toggle("hide");
    });
});