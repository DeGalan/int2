$(document).ready(function () {
    
    $(".menuCont").hide();
    $("#bg2").hide();
    
    $(".menuX").click(function () {
        $(".menuCont").fadeOut();
    });
    
    $(".mode").click(function () {
        $(".menuCont").fadeToggle();
    });
    
    $("#bg").click(function () {
        $("body").addClass("cBlack");
        $(".mode").addClass("dark");
        $(".guide").addClass("dark");
        $(".gTitle").addClass("dark");
        $("#bg2").show();
        $("#bg").hide();
    });
    
    $("#bg2").click(function () {
        $("body").removeClass("cBlack");
        $(".mode").removeClass("dark");
        $(".guide").removeClass("dark");
        $(".gTitle").removeClass("dark");
        $("#bg2").hide();
        $("#bg").show();
    });
    
});